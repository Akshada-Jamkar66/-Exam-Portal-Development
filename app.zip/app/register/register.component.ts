import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { User, UserService } from '../user.service';

@Component({
  selector: 'app-register',
  imports: [FormsModule, CommonModule],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent
{
  
  user:User=new User('','',0,'');
  users:User[]=[];
  message:string="";

  constructor(private userService:UserService)
  {
    
  }

  saveUser()
  {
    this.userService.saveUser(this.user).subscribe(userfromapi=>this.message=userfromapi.username + " your data is saved "); 
  }

}
