import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-score',
  imports: [CommonModule,FormsModule],
  templateUrl: './score.component.html',
  styleUrl: './score.component.css'
})
export class ScoreComponent implements OnInit
{

  score:any=0;
  allanswers : any = []
  data:any=''

  constructor(private activatedRoute:ActivatedRoute)
  {

  }



  ngOnInit(): void 
  {
    this.activatedRoute.queryParamMap.subscribe(queryparameters=>this.score=queryparameters.get("score"))
    this.activatedRoute.queryParamMap.subscribe(queryparameters=>{this.data=queryparameters.get("allanswers");this.allanswers=JSON.parse(this.data);})
  
  }
  
  compare(submittedAnswer:string,correctAnswer:string)
  {
    if(submittedAnswer==correctAnswer)
      return "green";
    else
      return "red";
  }

}
